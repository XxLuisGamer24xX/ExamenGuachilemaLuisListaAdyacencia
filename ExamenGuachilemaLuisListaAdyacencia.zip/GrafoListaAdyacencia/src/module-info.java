module GrafoListaAdyacencia {
}