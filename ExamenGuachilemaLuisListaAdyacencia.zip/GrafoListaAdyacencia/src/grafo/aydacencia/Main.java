package grafo.aydacencia;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu(20);
        menu.mostrarMenu();
    }
}
