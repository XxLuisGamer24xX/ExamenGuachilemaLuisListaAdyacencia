package grafo.aydacencia;

import java.util.Scanner;

public class Menu {
    private GrafoAdcia grafo;

    public Menu(int maxVerts) {
        grafo = new GrafoAdcia(maxVerts);
    }

    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        int opcion;        
        do {
            System.out.println("---------------------------------------------------------");
            System.out.println("               Meú principal Examen");
            System.out.println("---------------------------------------------------------");
            System.out.println("Precione 1..........................para Agregar vértice");
            System.out.println("Precione 2..........................para Agregar arco");
            System.out.println("Precione 3..........................para Verificar adyacencia");
            System.out.println("Precione 4..........................para recorrer grafo");
            System.out.println("Precione 5..........................para Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.println("---------------------------------------------------------");
                    System.out.println("                 Crear 1 vértice");
                    System.out.println("---------------------------------------------------------");
                    System.out.print("Ingrese el nombre de la ciudad: ");
                    String ciudad = scanner.next();
                    VerticeAdy vertice = new VerticeAdy(ciudad);
                    grafo.agregarVertice(vertice);
                    System.out.println("Vértice agregado con éxito.");
                    break;
                case 2:
                    System.out.println("---------------------------------------------------------");
                    System.out.println("                  Agregar Arco");
                    System.out.println("El número de vértice hace referencia a la posición la ");
                    System.out.println("lista de adyacencia en la que el vértice se encuentra guardo");
                    System.out.println("---------------------------------------------------------");
                    System.out.print("Ingrese el número del vértice origen: ");
                    int origen = scanner.nextInt();
                    System.out.print("Ingrese el número del vértice destino: ");
                    int destino = scanner.nextInt();
                    System.out.print("Ingrese el peso del arco: ");
                    double peso = scanner.nextDouble();
                    grafo.agregarArco(origen, destino, peso);
                    System.out.println("Arco agregado con éxito.");
                    break;
                case 3:
                    System.out.println("---------------------------------------------------------");
                    System.out.println("                 Verificar aydacencia");
                    System.out.println("El número de vértice hace referencia a la posición la ");
                    System.out.println("lista de adyacencia en la que el vértice se encuentra guardo");
                    System.out.println("---------------------------------------------------------");
                    System.out.print("Ingrese el número del vértice 1: ");
                    int v1 = scanner.nextInt();
                    System.out.print("Ingrese el número del vértice 2: ");
                    int v2 = scanner.nextInt();
                    if (grafo.sonAdyacentes(v1, v2)) {
                        System.out.println("Los vértices son adyacentes.");
                    } else {
                        System.out.println("Los vértices no son adyacentes.");
                    }
                    break;
                case 4:
                    System.out.println("---------------------------------------------------------");
                    System.out.println("                 Recorrer grafo");
                    System.out.println("El número de vértice hace referencia a la posición la ");
                    System.out.println("lista de adyacencia en la que el vértice se encuentra guardo");
                    System.out.println("---------------------------------------------------------");
                    System.out.print("Ingrese el número del vértice inicial para el recorrido en profundidad: ");
                    int inicioRecorrido = scanner.nextInt();
                    grafo.recorridoProfundidad(inicioRecorrido);
                    System.out.println("");
                 break;   
                case 5:
                    System.out.println("---------------------------------------------------------");
                    System.out.println("                 Muchas gracias por su visita");
                    System.out.println("---------------------------------------------------------");
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 5);
        
        scanner.close();
    }

    public static void main(String[] args) {
        Menu menu = new Menu(20); 
        menu.mostrarMenu();
    }
}
