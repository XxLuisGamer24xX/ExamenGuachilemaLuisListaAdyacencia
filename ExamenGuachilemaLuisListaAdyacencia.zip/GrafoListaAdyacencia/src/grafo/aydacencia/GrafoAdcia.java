package grafo.aydacencia;

public class GrafoAdcia {
    int numVerts;
    static int maxVerts = 20;
    VerticeAdy[] tablAdc;
    public GrafoAdcia(int mx) {
        tablAdc = new VerticeAdy[mx];
        numVerts = 0;
        maxVerts = mx;
    }
    
    //---------------------------------------------------------------------------
    //Agregar nueov vértice
    //---------------------------------------------------------------------------
    public void agregarVertice(VerticeAdy vertice) {
        if (numVerts < maxVerts) {
            tablAdc[numVerts] = vertice;
            vertice.asigVert(numVerts);
            numVerts++;
        }
    }
//---------------------------------------------------------------------------
    //Agregar nuevo arco
    //---------------------------------------------------------------------------
    public void agregarArco(int origen, int destino, double peso) {
        if (origen >= 0 && origen < numVerts && destino >= 0 && destino < numVerts) {
            Arco nuevoArco = new Arco(destino, peso);
            if (!buscarArco(origen, destino)) {
                tablAdc[origen].lad.add(nuevoArco);
            }
        }
    }
    //---------------------------------------------------------------------------
    //Buscar arco
    //---------------------------------------------------------------------------
    private boolean buscarArco(int origen, int destino) {
        for (Arco arco : tablAdc[origen].lad) {
            if (arco.getDestino() == destino) {
                return true;
            }
        }
        return false;
    }
    
    public boolean sonAdyacentes(int v1, int v2) {
        if (v1 >= 0 && v1 < numVerts && v2 >= 0 && v2 < numVerts) {
            return buscarArco(v1, v2);
        }
        return false;
    }
    
    //-----------------------------------------------------------------
    //                   Recorrido a profundidad
    //-----------------------------------------------------------------
    public void recorridoProfundidad(int verticeInicial) {
        boolean[] visitados = new boolean[numVerts];
        recorridoProfundidadAux(verticeInicial, visitados);
    }

    private void recorridoProfundidadAux(int vertice, boolean[] visitados) {
        visitados[vertice] = true;
        System.out.print(tablAdc[vertice].nomVertice() + " ");

        for (Arco arco : tablAdc[vertice].lad) {
            int destino = arco.getDestino();
            if (!visitados[destino]) {
                recorridoProfundidadAux(destino, visitados);
            }
        }
    }
}
